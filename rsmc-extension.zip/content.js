// content.js - RSMC Banner Injector

let __rsmcStopFlag = false;

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "start_injection") {
        __rsmcStopFlag = false;
        startInjection(request.data);
        sendResponse({status: "started"});
    }
    if (request.action === "stop_injection") {
        __rsmcStopFlag = true;
        console.log("[RSMC] Detencion solicitada.");
        sendResponse({status: "stopped"});
    }
    if (request.action === "delete_all") {
        __rsmcStopFlag = false;
        deleteAllRecords();
        sendResponse({status: "deleting"});
    }
});

// Sleep interrumpible
function sleep(ms) {
    return new Promise(resolve => {
        const step = 50;
        let elapsed = 0;
        const timer = setInterval(() => {
            elapsed += step;
            if (__rsmcStopFlag || elapsed >= ms) {
                clearInterval(timer);
                resolve();
            }
        }, step);
    });
}

function triggerChange(el) {
    if (!el) return;
    el.dispatchEvent(new Event('change', { bubbles: true }));
    el.dispatchEvent(new Event('input', { bubbles: true }));
    el.dispatchEvent(new Event('blur', { bubbles: true }));
    try { if (typeof jQuery !== 'undefined') jQuery(el).trigger('change'); } catch(e) {}
}

function sendProgress(current, total, status) {
    const state = { current, total, status, ts: Date.now() };
    chrome.storage.local.set({ rsmc_injection_state: state });
    try {
        chrome.runtime.sendMessage({ action: 'injection_progress', current, total, status });
    } catch(e) {}
}

function finishProcess() {
    setTimeout(() => chrome.storage.local.remove('rsmc_injection_state'), 5000);
}

// Selector universal para botones de eliminar en Banner
const DELETE_SELECTORS = [
    "input[value='Eliminar']",
    "input[value='eliminar']",
    "input[value='Delete']",
    "input[value='Borrar']",
    "button[title='Eliminar']",
    "button[title='Delete']",
    "a[title='Eliminar']",
    "a[title='Delete']",
    "img[alt='Eliminar']",
    "img[alt='Delete']"
].join(", ");

function findDeleteButton() {
    let btn = document.querySelector(DELETE_SELECTORS);
    if (!btn) {
        const allBtns = document.querySelectorAll("button, input[type='button'], a.btn");
        btn = Array.from(allBtns).find(b => {
            const txt = (b.value || b.textContent || '').toLowerCase();
            return txt.includes('eliminar') || txt.includes('delete') || txt.includes('borrar');
        });
    }
    if (btn && btn.tagName === 'IMG') {
        btn = btn.closest('a, button') || btn;
    }
    return btn;
}

function countDeleteButtons() {
    // Contar todos los botones de eliminar visibles
    let count = document.querySelectorAll(DELETE_SELECTORS).length;
    if (count === 0) {
        const allBtns = document.querySelectorAll("button, input[type='button'], a.btn");
        count = Array.from(allBtns).filter(b => {
            const txt = (b.value || b.textContent || '').toLowerCase();
            return txt.includes('eliminar') || txt.includes('delete') || txt.includes('borrar');
        }).length;
    }
    return count;
}

// =================== INYECCION ===================

async function startInjection(data) {
    console.log("[RSMC] Iniciando inyeccion de", data.length, "filas...");
    await sleep(50);

    for (let i = 0; i < data.length; i++) {
        if (__rsmcStopFlag) {
            sendProgress(i, data.length, 'stopped');
            break;
        }

        let item = data[i];
        sendProgress(i + 1, data.length, 'running');

        try {
            // --- METODOLOGIA ---
            let selUnidades = document.querySelector("#sel-unidades");
            if (!selUnidades) {
                sendProgress(i, data.length, 'error');
                break;
            }

            selUnidades.value = item.unidad;
            triggerChange(selUnidades);
            await sleep(15);
            if (__rsmcStopFlag) { sendProgress(i, data.length, 'stopped'); break; }

            let selSubunidades = document.querySelector("#sel-subunidades");
            if (!selSubunidades) continue;

            let activeTema = item.tema;
            let temaOpt = Array.from(selSubunidades.options).find(o => o.value === item.tema);

            if (!temaOpt) {
                let fallback = parseInt(item.unidad, 10) + ".01";
                activeTema = fallback;
                temaOpt = Array.from(selSubunidades.options).find(o => o.value === activeTema);
                if (!temaOpt) continue;
            }

            selSubunidades.value = activeTema;
            triggerChange(selSubunidades);
            await sleep(5);
            if (__rsmcStopFlag) { sendProgress(i, data.length, 'stopped'); break; }

            const metDesc = document.querySelector("#act-description");
            const metComp = document.querySelector("#sel-compoaprendizaje");

            if (metDesc) {
                metDesc.value = item.met_desc;
                triggerChange(metDesc);
            }
            if (metComp) {
                let compOpt = Array.from(metComp.options).find(o =>
                    o.value.includes(item.met_comp) || o.text.includes(item.met_comp)
                );
                if (compOpt) {
                    metComp.value = compOpt.value;
                    triggerChange(metComp);
                }
            }

            let addBtnMet = metDesc?.closest("tr")?.querySelector("button, input[value='Agregar'], input[type='button'], a");
            if (addBtnMet) addBtnMet.click();
            await sleep(25);
            if (__rsmcStopFlag) { sendProgress(i, data.length, 'stopped'); break; }

            // --- EVALUACION ---
            const comboUni = document.querySelector("#combo-unidades");
            if (comboUni) {
                comboUni.value = item.unidad;
                triggerChange(comboUni);
                await sleep(500);
                if (__rsmcStopFlag) { sendProgress(i, data.length, 'stopped'); break; }

                let comboSub = document.querySelector("#combo-subunidades");
                if (comboSub) {
                    let subOpt = Array.from(comboSub.options).find(o => o.value === activeTema);
                    if (subOpt) {
                        comboSub.value = subOpt.value;
                        triggerChange(comboSub);
                    }
                }
                await sleep(150);
                if (__rsmcStopFlag) { sendProgress(i, data.length, 'stopped'); break; }

                let evalDesc = document.querySelector("#method-description");
                if (evalDesc) {
                    evalDesc.value = item.eval_desc;
                    triggerChange(evalDesc);
                }

                let addBtnEval = evalDesc?.closest("tr")?.querySelector("button, input[value='Agregar'], input[type='button'], a");
                if (addBtnEval) addBtnEval.click();
                await sleep(750);
                if (__rsmcStopFlag) { sendProgress(i, data.length, 'stopped'); break; }
            }

            // --- RESULTADOS DE APRENDIZAJE ---
            const raComboUni = document.querySelector("#ra_combo-unidades");
            if (raComboUni) {
                raComboUni.value = item.unidad;
                triggerChange(raComboUni);
                await sleep(500);
                if (__rsmcStopFlag) { sendProgress(i, data.length, 'stopped'); break; }

                let raSub = document.querySelector("#ra_combo-subunidades");
                if (raSub) {
                    let rsOpt = Array.from(raSub.options).find(o => o.value === activeTema);
                    if (rsOpt) {
                        raSub.value = rsOpt.value;
                        triggerChange(raSub);
                    }
                }
                await sleep(150);
                if (__rsmcStopFlag) { sendProgress(i, data.length, 'stopped'); break; }

                let raCombo = document.querySelector("#ra-combo");
                if (raCombo) {
                    let raOpt = Array.from(raCombo.options).find(o =>
                        o.value === item.ra_id ||
                        o.text.includes(item.ra_id) ||
                        o.value.includes(item.ra_id)
                    );

                    if (raOpt) {
                        raCombo.value = raOpt.value;
                        triggerChange(raCombo);

                        let addBtnRa = raCombo.closest("tr")?.querySelector("button, input[value='Agregar'], input[type='button'], a");
                        if (addBtnRa) addBtnRa.click();
                    }
                }
                await sleep(750);
                if (__rsmcStopFlag) { sendProgress(i, data.length, 'stopped'); break; }
            }

        } catch (e) {
            console.error(`Error en fila ${i}: ${e.message}`);
        }
    }

    if (!__rsmcStopFlag) {
        sendProgress(data.length, data.length, 'done');
    }
    finishProcess();
}

// =================== BORRADO ===================

async function deleteAllRecords() {
    console.log("[RSMC] Contando registros a eliminar...");

    // Contar total ANTES de empezar
    const total = countDeleteButtons();
    console.log(`[RSMC] ${total} registros encontrados para eliminar.`);

    if (total === 0) {
        sendProgress(0, 0, 'delete_done');
        finishProcess();
        return;
    }

    sendProgress(0, total, 'deleting');
    let deleted = 0;

    for (let i = 0; i < total + 50; i++) { // +50 margen por si aparecen mas
        if (__rsmcStopFlag) {
            console.log("[RSMC] Borrado detenido.");
            sendProgress(deleted, total, 'stopped');
            finishProcess();
            return;
        }

        let btn = findDeleteButton();
        if (!btn) break;

        btn.click();
        deleted++;
        sendProgress(deleted, total, 'deleting');
        await sleep(15);
    }

    console.log(`[RSMC] Borrado completado. ${deleted} registros eliminados.`);
    sendProgress(deleted, total, 'delete_done');
    finishProcess();
}
