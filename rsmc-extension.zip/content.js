// content.js - RSMC Banner Injector

let __rsmcStopFlag = false;

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "start_injection") {
        __rsmcStopFlag = false;
        startInjection(request.data);
        sendResponse({status: "started"});
    }
    if (request.action === "stop_injection") {
        __rsmcStopFlag = true;
        console.log("[RSMC] Detención solicitada por el usuario.");
        sendResponse({status: "stopped"});
    }
});

const sleep = ms => new Promise(r => setTimeout(r, ms));

function triggerChange(el) {
    if (!el) return;
    el.dispatchEvent(new Event('change', { bubbles: true }));
    el.dispatchEvent(new Event('input', { bubbles: true }));
    el.dispatchEvent(new Event('blur', { bubbles: true }));
    try { if (typeof jQuery !== 'undefined') jQuery(el).trigger('change'); } catch(e) {}
}

async function startInjection(data) {
    console.log("🚀 [RSMC] Iniciando inyección de", data.length, "filas...");

    // Silenciar alertas ANTES de cualquier interacción

    await sleep(500);

    for (let i = 0; i < data.length; i++) {
        if (__rsmcStopFlag) {
            console.log("🛑 [RSMC] Inyección detenida por el usuario.");
            break;
        }

        let item = data[i];
        console.log(`\n⏳ [${i+1}/${data.length}] Unidad ${item.unidad} - Tema ${item.tema}`);

        try {
            // ---------------- METODOLOGÍA ----------------
            let selUnidades = document.querySelector("#sel-unidades");
            if (!selUnidades) {
                console.error("❌ No se encontró #sel-unidades. ¿Estás en la página correcta de Banner?");
                break;
            }

            selUnidades.value = item.unidad;
            triggerChange(selUnidades);
            await sleep(2000);

            let selSubunidades = document.querySelector("#sel-subunidades");
            if (!selSubunidades) { console.warn("⚠️ No se encontró #sel-subunidades"); continue; }

            let activeTema = item.tema;
            let temaOpt = Array.from(selSubunidades.options).find(o => o.value === item.tema);

            if (!temaOpt) {
                // Fallback: primer subtema de la unidad
                let fallback = parseInt(item.unidad, 10) + ".01";
                console.warn(`⚠️ Tema ${item.tema} no existe, fallback a ${fallback}`);
                activeTema = fallback;
                temaOpt = Array.from(selSubunidades.options).find(o => o.value === activeTema);
                if (!temaOpt) { console.warn("⚠️ Fallback tampoco existe, saltando"); continue; }
            }

            selSubunidades.value = activeTema;
            triggerChange(selSubunidades);
            await sleep(500);

            const metDesc = document.querySelector("#act-description");
            const metComp = document.querySelector("#sel-compoaprendizaje");

            if (metDesc) {
                metDesc.value = item.met_desc;
                triggerChange(metDesc);
            }
            if (metComp) {
                // Buscar opción que contenga el código
                let compOpt = Array.from(metComp.options).find(o =>
                    o.value.includes(item.met_comp) || o.text.includes(item.met_comp)
                );
                if (compOpt) {
                    metComp.value = compOpt.value;
                    triggerChange(metComp);
                } else {
                    console.warn(`⚠️ met_comp "${item.met_comp}" no encontrado en opciones`);
                }
            }

            // Re-silenciar alertas antes de click (por si Banner los restauró)
        

            let addBtnMet = metDesc?.closest("tr")?.querySelector("button, input[value='Agregar'], input[type='button'], a");
            if (addBtnMet) {
                addBtnMet.click();
                console.log("✔️ METODOLOGÍA agregada");
            }
            await sleep(3000);

            // ---------------- EVALUACIÓN ----------------
            const comboUni = document.querySelector("#combo-unidades");
            if (comboUni) {
                comboUni.value = item.unidad;
                triggerChange(comboUni);
                await sleep(2000);

                let comboSub = document.querySelector("#combo-subunidades");
                if (comboSub) {
                    let subOpt = Array.from(comboSub.options).find(o => o.value === activeTema);
                    if (subOpt) {
                        comboSub.value = subOpt.value;
                        triggerChange(comboSub);
                    }
                }
                await sleep(500);

                let evalDesc = document.querySelector("#method-description");
                if (evalDesc) {
                    evalDesc.value = item.eval_desc;
                    triggerChange(evalDesc);
                }

            
                let addBtnEval = evalDesc?.closest("tr")?.querySelector("button, input[value='Agregar'], input[type='button'], a");
                if (addBtnEval) {
                    addBtnEval.click();
                    console.log("✔️ EVALUACIÓN agregada");
                }
                await sleep(3000);
            }

            // ---------------- RESULTADOS DE APRENDIZAJE ----------------
            const raComboUni = document.querySelector("#ra_combo-unidades");
            if (raComboUni) {
                raComboUni.value = item.unidad;
                triggerChange(raComboUni);
                await sleep(2000);

                let raSub = document.querySelector("#ra_combo-subunidades");
                if (raSub) {
                    let rsOpt = Array.from(raSub.options).find(o => o.value === activeTema);
                    if (rsOpt) {
                        raSub.value = rsOpt.value;
                        triggerChange(raSub);
                    }
                }
                await sleep(500);

                let raCombo = document.querySelector("#ra-combo");
                if (raCombo) {
                    // Log de opciones disponibles para debug
                    let raOptions = Array.from(raCombo.options).map(o => `${o.value} | ${o.text}`);
                    console.log("📋 Opciones RA disponibles:", raOptions);

                    // Intentar match por ra_id, o por texto parcial
                    let raOpt = Array.from(raCombo.options).find(o =>
                        o.value === item.ra_id ||
                        o.text.includes(item.ra_id) ||
                        o.value.includes(item.ra_id)
                    );

                    if (raOpt) {
                        raCombo.value = raOpt.value;
                        triggerChange(raCombo);

                    
                        let addBtnRa = raCombo.closest("tr")?.querySelector("button, input[value='Agregar'], input[type='button'], a");
                        if (addBtnRa) {
                            addBtnRa.click();
                            console.log("✔️ RESULTADO DE APRENDIZAJE agregado");
                        }
                    } else {
                        console.warn(`⚠️ ra_id "${item.ra_id}" no coincide con opciones de Banner. Saltando RA.`);
                    }
                }
                await sleep(3000);
            }

        } catch (e) {
            console.error(`❌ Error en fila ${i}: ${e.message}`);
        }
    }

    console.log("✅ [RSMC] PROCESO COMPLETADO");
}
