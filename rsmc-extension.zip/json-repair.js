/**
 * Port de repair_raw_json y validate_and_fix de Python a JavaScript.
 * Extrae registros del texto crudo usando regex, inmune a truncamientos del modelo AI.
 */

function repairRawJson(raw) {
  const results = [];
  const chunks = raw.split('{');

  for (let chunk of chunks) {
    if (!chunk.includes('}')) continue;
    chunk = chunk.substring(0, chunk.lastIndexOf('}') + 1);

    const record = {};

    // Extraer campos con key exacta: "field": "value"
    for (const field of FIELD_ORDER) {
      const regex = new RegExp(`"${field}"\\s*:\\s*"([^"]*)"`, '');
      const match = chunk.match(regex);
      if (match) {
        record[field] = match[1].trim();
      }
    }

    // Extraer met_comp aunque la key esté corrupta — buscar CD/APE/TA sueltos
    if (!record.met_comp) {
      const compMatch = chunk.match(/:\s*"(CD|APE|TA)"/);
      if (compMatch) record.met_comp = compMatch[1];
    }

    // Extraer unidad de dígitos si la key se corrompió
    if (!record.unidad) {
      const unitMatch = chunk.match(/"(\d{1,2})\w*"\s*:/);
      if (unitMatch) record.unidad = unitMatch[1].padStart(2, '0');
    }

    // Extraer tema si falta — buscar patrón N.N en el chunk
    if (!record.tema && record.unidad) {
      const temaMatch = chunk.match(/"(\d+\.\d+)"/);
      if (temaMatch) record.tema = temaMatch[1];
    }

    // Extraer ra_id si falta
    if (!record.ra_id) {
      const raMatch = chunk.match(/"([A-Z]\d{3}-\d{3}|\d{1,3})"\s*\}/);
      if (raMatch) record.ra_id = raMatch[1];
    }

    // Aceptar registro si tiene al menos met_comp y (unidad o tema)
    if (record.met_comp && (record.unidad || record.tema)) {
      if (!record.unidad && record.tema) {
        record.unidad = record.tema.split('.')[0].padStart(2, '0');
      }
      for (const f of FIELD_ORDER) {
        if (!(f in record)) record[f] = '';
      }
      results.push(record);
    }
  }

  return results;
}

function validateAndFix(data) {
  if (!Array.isArray(data)) throw new Error('La respuesta de la IA no es un array JSON.');

  const cleaned = [];

  for (const item of data) {
    if (typeof item !== 'object' || item === null) continue;

    const fixed = {};
    const keys = Object.keys(item);

    for (const [k, v] of Object.entries(item)) {
      if (REQUIRED_FIELDS.has(k)) {
        fixed[k] = v != null ? String(v) : '';
      } else if (typeof v === 'string') {
        if (!fixed.met_desc && !item.met_desc) {
          fixed.met_desc = String(v);
        }
      }
    }

    // Verificar campos obligatorios
    const missing = FIELD_ORDER.filter(f => !(f in fixed));
    if (missing.length > 0) {
      if (missing.length === 1 && missing[0] === 'met_desc') {
        for (const k of keys) {
          if (!REQUIRED_FIELDS.has(k) && typeof item[k] === 'string') {
            fixed.met_desc = item[k];
            break;
          }
        }
        if (!fixed.met_desc) fixed.met_desc = '';
      }
      const stillMissing = FIELD_ORDER.filter(f => !(f in fixed) && f !== 'met_desc');
      if (stillMissing.length > 0) continue;
    }

    // Normalizar unidad a 2 dígitos
    let unidad = fixed.unidad || '';
    const unidadDigits = unidad.replace(/[^\d]/g, '');
    if (unidadDigits) fixed.unidad = unidadDigits.padStart(2, '0');

    // Si unidad es "00", inferir del tema
    if ((fixed.unidad || '00') === '00' && fixed.tema) {
      const parts = fixed.tema.split('.');
      if (/^\d+$/.test(parts[0])) {
        fixed.unidad = parts[0].padStart(2, '0');
      }
    }

    // Normalizar tema
    const tema = fixed.tema || '';
    if (!/^\d+\.\d+$/.test(tema)) {
      const unitNum = parseInt(fixed.unidad, 10);
      const prevCount = cleaned.filter(c => c.unidad === fixed.unidad).length;
      fixed.tema = `${unitNum}.${prevCount + 1}`;
    }

    // Validar met_comp
    if (!VALID_MET_COMP.has(fixed.met_comp || '')) {
      fixed.met_comp = 'APE';
    }

    cleaned.push(fixed);
  }

  if (cleaned.length === 0) throw new Error('No se pudo extraer ningún registro válido.');

  return cleaned;
}

function processRawResponse(rawJson) {
  rawJson = rawJson.replace(/```json/g, '').replace(/```/g, '').trim();

  const bracketStart = rawJson.indexOf('[');
  const bracketEnd = rawJson.lastIndexOf(']');
  if (bracketStart !== -1 && bracketEnd !== -1) {
    rawJson = rawJson.substring(bracketStart, bracketEnd + 1);
  }

  let finalData = repairRawJson(rawJson);

  if (!finalData.length) {
    throw new Error('La IA devolvió texto irrecuperable. Intenta de nuevo o usa otro modelo.');
  }

  finalData = validateAndFix(finalData);

  for (const record of finalData) {
    for (const field of FIELD_ORDER) {
      if (!(field in record)) record[field] = '';
      record[field] = String(record[field]);
    }
  }

  return finalData;
}
