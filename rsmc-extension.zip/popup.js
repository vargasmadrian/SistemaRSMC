// ============================================================
// Sistema RSMC - Popup Controller
// ============================================================

// --- Elementos del DOM ---
const providerEl   = document.getElementById('provider');
const apiKeyEl     = document.getElementById('apiKey');
const apiKeyLinkEl = document.getElementById('apiKeyLink');
const fileInputEl  = document.getElementById('fileInput');
const fileNameEl   = document.getElementById('fileName');
const dropZoneEl   = document.getElementById('dropZone');
const analyzeBtnEl = document.getElementById('analyzeBtn');
const statusEl     = document.getElementById('status');
const configSection  = document.getElementById('config-section');
const resultsSection = document.getElementById('results-section');
const tableBodyEl  = document.getElementById('tableBody');
const rowCountEl   = document.getElementById('rowCount');
const injectBtnEl  = document.getElementById('injectBtn');
const stopBtnEl    = document.getElementById('stopBtn');
const deleteAllBtnEl = document.getElementById('deleteAllBtn');
const backBtnEl    = document.getElementById('backBtn');
const progressWrapper = document.getElementById('progressWrapper');
const progressLabel   = document.getElementById('progressLabel');
const progressCount   = document.getElementById('progressCount');
const progressFill    = document.getElementById('progressFill');

// --- Links de API Key por provider ---
function getProviderLink() {
  const p = providerEl.value;
  if (p.startsWith('gemini')) return 'https://aistudio.google.com/app/apikey';
  if (p.startsWith('openai')) return 'https://platform.openai.com/api-keys';
  return '#';
}

function updateApiKeyLink() {
  apiKeyLinkEl.href = getProviderLink();
}

// --- Persistencia de API keys con chrome.storage ---
providerEl.addEventListener('change', () => {
  updateApiKeyLink();
  const key = `rsmc_key_${providerEl.value}`;
  chrome.storage.local.get(key, (result) => {
    apiKeyEl.value = result[key] || '';
    updateAnalyzeButton();
  });
});

apiKeyEl.addEventListener('input', () => {
  const key = `rsmc_key_${providerEl.value}`;
  chrome.storage.local.set({ [key]: apiKeyEl.value });
  updateAnalyzeButton();
});

// --- Restaurar estado al abrir popup ---
function restoreState() {
  // 1. API Key
  chrome.storage.local.get(`rsmc_key_${providerEl.value}`, (result) => {
    apiKeyEl.value = result[`rsmc_key_${providerEl.value}`] || '';
    updateAnalyzeButton();
  });
  updateApiKeyLink();

  // 2. Datos procesados (si existen)
  chrome.storage.local.get(['rsmc_processed_data', 'rsmc_injection_state'], (result) => {
    const data = result.rsmc_processed_data;
    if (data && Array.isArray(data) && data.length > 0) {
      renderTable(data);
      configSection.style.display = 'none';
      resultsSection.style.display = 'block';
    }

    // 3. Restaurar barra de progreso si hay proceso activo
    const state = result.rsmc_injection_state;
    if (state) {
      // Si el estado tiene más de 60s, probablemente es un estado viejo que no se limpió
      const age = Date.now() - (state.ts || 0);
      if (age > 60000 && (state.status === 'deleting' || state.status === 'running')) {
        chrome.storage.local.remove('rsmc_injection_state');
      } else {
        handleProgressUpdate(state);
      }
    }
  });
}

restoreState();

// --- File input ---
fileInputEl.addEventListener('change', () => {
  const file = fileInputEl.files[0];
  if (file) {
    fileNameEl.textContent = file.name;
    fileNameEl.style.display = 'inline-block';
    dropZoneEl.classList.add('has-file');
  }
  updateAnalyzeButton();
});

function updateAnalyzeButton() {
  analyzeBtnEl.disabled = !(fileInputEl.files[0] && apiKeyEl.value.trim());
}

// --- Status helpers ---
function showStatus(msg, type) {
  statusEl.style.display = 'block';
  statusEl.className = `status ${type}`;
  statusEl.innerHTML = msg;
}
function hideStatus() {
  statusEl.style.display = 'none';
}

// --- Barra de progreso ---
function showProgress(current, total, label, state) {
  progressWrapper.style.display = 'block';
  progressLabel.textContent = label;
  progressCount.textContent = total > 0 ? `${current}/${total}` : `${current}`;
  const pct = total > 0 ? Math.round((current / total) * 100) : 0;
  progressFill.style.width = pct + '%';
  progressFill.className = 'progress-fill' + (state ? ` ${state}` : '');
}

function hideProgress() {
  progressWrapper.style.display = 'none';
  progressFill.style.width = '0%';
}

// --- Procesar actualizacion de progreso ---
function handleProgressUpdate(state) {
  if (!state) return;
  const { current, total, status } = state;

  if (status === 'running') {
    showProgress(current, total, 'Inyectando...', '');
    injectBtnEl.style.display = 'none';
    stopBtnEl.style.display = 'inline-block';
  } else if (status === 'stopped') {
    showProgress(current, total, 'Detenido', 'stopped');
    resetInjectionButtons();
  } else if (status === 'done') {
    showProgress(total, total, 'Completado', 'done');
    resetInjectionButtons();
    showResultsStatus('Inyeccion completada exitosamente.', 'success');
  } else if (status === 'error') {
    showProgress(current, total, 'Error', 'stopped');
    resetInjectionButtons();
  } else if (status === 'deleting') {
    showProgress(current, total, total > 0 ? `Borrando... ${current}/${total}` : 'Borrando...', 'deleting');
    deleteAllBtnEl.disabled = true;
    deleteAllBtnEl.textContent = 'Borrando...';
    // Mostrar stop durante borrado
    injectBtnEl.style.display = 'none';
    stopBtnEl.style.display = 'inline-block';
  } else if (status === 'delete_done') {
    showProgress(current, total || current, `${current} registros eliminados`, 'done');
    deleteAllBtnEl.disabled = false;
    deleteAllBtnEl.textContent = 'Borrar registros';
    resetInjectionButtons();
    showResultsStatus(`${current} registros eliminados de Banner.`, 'success');
  }
}

// --- Escuchar mensajes directos del content script ---
chrome.runtime.onMessage.addListener((msg) => {
  if (msg.action === 'injection_progress') {
    handleProgressUpdate(msg);
  }
});

// --- Escuchar cambios en storage (funciona incluso si el popup se reabrió) ---
chrome.storage.onChanged.addListener((changes, area) => {
  if (area === 'local' && changes.rsmc_injection_state) {
    const state = changes.rsmc_injection_state.newValue;
    if (state) {
      handleProgressUpdate(state);
    } else {
      // Estado fue limpiado (proceso terminó)
      hideProgress();
    }
  }
});

function resetInjectionButtons() {
  stopBtnEl.style.display = 'none';
  injectBtnEl.style.display = 'inline-block';
}

// --- ANALISIS: PDF -> IA -> Repair -> Tabla ---
analyzeBtnEl.addEventListener('click', async () => {
  const file = fileInputEl.files[0];
  const provider = providerEl.value;
  const apiKey = apiKeyEl.value.trim();

  if (!file || !apiKey) return;

  analyzeBtnEl.disabled = true;
  showStatus('<span class="spinner"></span> Extrayendo texto del PDF...', 'loading');

  try {
    // 1. Extraer texto del PDF
    const text = await extractTextFromPDF(file);
    if (!text.trim()) throw new Error('El PDF esta vacio o no se pudo leer.');

    showStatus('<span class="spinner"></span> Enviando a la IA... (puede tomar ~1 min)', 'loading');

    // 2. Llamar a la IA
    const rawJson = await callAI(provider, apiKey, text);

    showStatus('<span class="spinner"></span> Procesando respuesta...', 'loading');

    // 3. Repair + Validar
    const processedData = processRawResponse(rawJson);

    // 4. Guardar en storage para persistir entre aperturas del popup
    chrome.storage.local.set({ rsmc_processed_data: processedData });

    // 5. Mostrar tabla editable
    renderTable(processedData);
    configSection.style.display = 'none';
    resultsSection.style.display = 'block';
    hideStatus();

  } catch (err) {
    showStatus(classifyError(err), 'error');
    analyzeBtnEl.disabled = false;
  }
});

// --- Renderizar tabla editable ---
function renderTable(data) {
  rowCountEl.textContent = `${data.length} filas`;
  tableBodyEl.innerHTML = '';

  for (let i = 0; i < data.length; i++) {
    const row = data[i];
    const tr = document.createElement('tr');
    tr.innerHTML = `
      <td><input class="input-unit" data-row="${i}" data-field="unidad" value="${esc(row.unidad)}"></td>
      <td><input class="input-tema" data-row="${i}" data-field="tema" value="${esc(row.tema)}"></td>
      <td>
        <select data-row="${i}" data-field="met_comp">
          <option value="CD" ${row.met_comp === 'CD' ? 'selected' : ''}>CD</option>
          <option value="APE" ${row.met_comp === 'APE' ? 'selected' : ''}>APE</option>
          <option value="TA" ${row.met_comp === 'TA' ? 'selected' : ''}>TA</option>
        </select>
      </td>
      <td><input data-row="${i}" data-field="met_desc" value="${esc(row.met_desc)}"></td>
      <td><input data-row="${i}" data-field="eval_desc" value="${esc(row.eval_desc)}"></td>
      <td><input class="input-ra" data-row="${i}" data-field="ra_id" value="${esc(row.ra_id)}"></td>
    `;
    tableBodyEl.appendChild(tr);
  }

  // Guardar ediciones automaticamente cuando el usuario modifica un campo
  tableBodyEl.addEventListener('input', saveTableToStorage);
  tableBodyEl.addEventListener('change', saveTableToStorage);
}

function saveTableToStorage() {
  const data = getTableData();
  chrome.storage.local.set({ rsmc_processed_data: data });
}

function esc(str) {
  return (str || '').replace(/"/g, '&quot;').replace(/</g, '&lt;');
}

// --- Leer datos actuales de la tabla (con ediciones del usuario) ---
function getTableData() {
  const rows = tableBodyEl.querySelectorAll('tr');
  const data = [];
  rows.forEach(tr => {
    const record = {};
    tr.querySelectorAll('input, select').forEach(el => {
      record[el.dataset.field] = el.value;
    });
    data.push(record);
  });
  return data;
}

// --- Inyectar en Banner ---
injectBtnEl.addEventListener('click', async () => {
  const data = getTableData();

  if (!data.length) return;

  injectBtnEl.style.display = 'none';
  stopBtnEl.style.display = 'inline-block';
  showProgress(0, data.length, 'Iniciando...', '');

  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });

    // Silenciar alert/confirm en MAIN world
    await chrome.scripting.executeScript({
      target: { tabId: tab.id, allFrames: true },
      world: 'MAIN',
      func: () => {
        window.__rsmcOrigAlert = window.alert;
        window.__rsmcOrigConfirm = window.confirm;
        window.alert = function(msg) { console.log('[RSMC] Alert silenciado:', msg); };
        window.confirm = function(msg) { console.log('[RSMC] Confirm auto-aceptado:', msg); return true; };
      }
    });

    // Enviar datos al content script
    chrome.tabs.sendMessage(tab.id, { action: 'start_injection', data }, (response) => {
      if (chrome.runtime.lastError) {
        resetInjectionButtons();
        hideProgress();
        showResultsStatus('No se pudo conectar con Banner. Recarga la pagina (F5).', 'error');
        return;
      }
    });
  } catch (e) {
    resetInjectionButtons();
    hideProgress();
    showResultsStatus(classifyError(e), 'error');
  }
});

// --- Detener inyeccion ---
stopBtnEl.addEventListener('click', async () => {
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    chrome.tabs.sendMessage(tab.id, { action: 'stop_injection' });
  } catch (e) { /* ignore */ }

  resetInjectionButtons();
  showResultsStatus('Inyeccion detenida.', 'error');
});

// --- Borrar todos los registros de Banner ---
deleteAllBtnEl.addEventListener('click', async () => {
  const confirm = window.confirm('¿Seguro que quieres borrar TODOS los registros inyectados en Banner?');
  if (!confirm) return;

  deleteAllBtnEl.disabled = true;
  deleteAllBtnEl.textContent = 'Borrando...';
  showProgress(0, 0, 'Borrando registros...', 'deleting');

  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });

    // Silenciar alert/confirm para el borrado tambien
    await chrome.scripting.executeScript({
      target: { tabId: tab.id, allFrames: true },
      world: 'MAIN',
      func: () => {
        window.alert = function(msg) { console.log('[RSMC] Alert silenciado:', msg); };
        window.confirm = function(msg) { console.log('[RSMC] Confirm auto-aceptado:', msg); return true; };
      }
    });

    chrome.tabs.sendMessage(tab.id, { action: 'delete_all' }, (response) => {
      if (chrome.runtime.lastError) {
        deleteAllBtnEl.disabled = false;
        deleteAllBtnEl.textContent = 'Borrar registros';
        hideProgress();
        showResultsStatus('No se pudo conectar con Banner. Recarga la pagina (F5).', 'error');
      }
    });
  } catch (e) {
    deleteAllBtnEl.disabled = false;
    deleteAllBtnEl.textContent = 'Borrar registros';
    hideProgress();
    showResultsStatus(classifyError(e), 'error');
  }
});

function showResultsStatus(msg, type) {
  const prev = resultsSection.querySelector('.inject-status');
  if (prev) prev.remove();

  const div = document.createElement('div');
  div.className = `status ${type} inject-status`;
  div.style.marginTop = '8px';
  div.textContent = msg;
  resultsSection.appendChild(div);

  setTimeout(() => div.remove(), 5000);
}

// --- Volver a config ---
backBtnEl.addEventListener('click', () => {
  resultsSection.style.display = 'none';
  configSection.style.display = 'block';
  analyzeBtnEl.disabled = false;
  hideStatus();
  hideProgress();
  chrome.storage.local.remove('rsmc_processed_data');
});
